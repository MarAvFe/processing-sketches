Particle p1, p2;
Spring s;
ArrayList<IAgent> agents;

void setup(){
    size(800,600,FX2D);
    background(100,200,100);
    p1 = new Particle(width/2-100, height/2, 1, 0);
    p2 = new Particle(width/2+100, height/2, 1, 0);
    s = new Spring(p1,p2,1.0,150.0);

    agents = new ArrayList();
    agents.add(p1);
    agents.add(p2);
    agents.add(s);
}

void draw(){
    background(0);
    for(IAgent a : agents){
        a.update();
        a.draw();
    }
}
